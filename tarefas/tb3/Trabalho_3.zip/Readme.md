# Trabalho 3 - Matematica e Física para Jogos

## Detecção de Colisão de Dois Segmentos

**Antonio Gabriel Magalhães Alves - 496218**

### Tecnologia usada:

- P5.js

### Features:
- Para dois segmentos de reta não colineares, as retas ficam verdes e é marcado o ponto de intersecção na tela e mostrado suas coordenadas.

- Para dois segmentos colineares, os dois segmentos são pintados de azul e não é marcado nenhuma intersecção.

- Para dois segmentos de reta não colineares que não se cruzam as retas são pintadas de vermelho.

### Como executar:

            Execute o script no P5.js
